package com.example.loginapp;

import java.io.Serializable;

public class Users implements Serializable {
    String name;
    String email;
    String number;
    int password;

    public Users(String name, String email, String number, int password) {
        this.name = name;
        this.email = email;
        this.number = number;
        this.password = password;
    }
}
