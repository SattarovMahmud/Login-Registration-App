package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {

    Button btn;
    EditText et1, et2, et3, et4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btn = findViewById(R.id.reg);

        et1 = findViewById(R.id.et_name);
        et2 = findViewById(R.id.et_email);
        et3 = findViewById(R.id.et_number);
        et4 = findViewById(R.id.et_password);

        Intent i = new Intent(this, LoginActivity.class);

        btn.setOnClickListener(view -> {
            String name = et1.getText().toString();
            String email = et2.getText().toString();
            String number = et3.getText().toString();
            int password = Integer.parseInt(et4.getText().toString());
            Users setUser = new Users(name,email,number,password);
            i.putExtra("DATA",setUser);
            startActivity(i);
        });
    }
}