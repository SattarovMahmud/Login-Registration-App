package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    List<Users> usersList = new ArrayList<>();

    TextView reg;
    TextInputEditText et1, et2;
    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et1 = findViewById(R.id.et_email);
        et2 = findViewById(R.id.et_password);
        btn1 = findViewById(R.id.login);
        reg = findViewById(R.id.new_user);

        Users getUser = (Users) getIntent().getSerializableExtra("DATA");

        if (usersList != null)
            usersList.add(getUser);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (et1.getText().toString().equals("") || et2.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Login va parol kiriting", Toast.LENGTH_LONG).show();
                    return;
                }
                for (Users i : usersList) {
                    if (getUser.email.equals(et1.getText().toString()) && getUser.password == Integer.parseInt(et2.getText().toString())) {
                        Intent i1 = new Intent(getApplicationContext(), WelcomeActivity.class);
                        i1.putExtra("DATA2",getUser);
                        startActivity(i1);
                        return;
                    }
                }
                Toast.makeText(getApplicationContext(), "Login yoki parol xato", Toast.LENGTH_LONG).show();
            }
        });

        reg.setOnClickListener(view ->  {
                Intent j = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(j);
            }
        );
    }
}